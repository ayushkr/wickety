package com.example.wicketyandroid;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FirstConnectActivity extends AppCompatActivity {

    Button register,guest;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.a02_first_connect);

        register=(Button)findViewById(R.id.register_a02);
        guest=(Button)findViewById(R.id.guest_a02);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(FirstConnectActivity.this,AuthenticationEntry.class);
                startActivity(i);
            }
        });


        guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(FirstConnectActivity.this,ScoreBoard.class);
                startActivity(i);
            }
        });
    }

}



